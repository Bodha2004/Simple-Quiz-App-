import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.get(api.quizzes.list.path, async (req, res) => {
    const quizzes = await storage.getQuizzes();
    res.json(quizzes);
  });

  app.get(api.quizzes.get.path, async (req, res) => {
    const quiz = await storage.getQuiz(Number(req.params.id));
    if (!quiz) {
      return res.status(404).json({ message: "Quiz not found" });
    }
    res.json(quiz);
  });

  // Seed data
  const existing = await storage.getQuizzes();
  if (existing.length === 0) {
    const quiz1 = await storage.createQuiz({
      title: "General Knowledge",
      description: "Test your general knowledge with these fun questions!"
    });
    
    const gk_questions = [
      { q: "What is the capital of France?", opts: ["London", "Berlin", "Paris", "Madrid"], ans: 2 },
      { q: "Which planet is known as the Red Planet?", opts: ["Venus", "Mars", "Jupiter", "Saturn"], ans: 1 },
      { q: "Who wrote 'Romeo and Juliet'?", opts: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"], ans: 1 },
      { q: "What is the largest ocean on Earth?", opts: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"], ans: 3 },
      { q: "Which element has the chemical symbol 'Au'?", opts: ["Silver", "Gold", "Copper", "Aluminum"], ans: 1 },
      { q: "What is the smallest country in the world?", opts: ["Monaco", "Vatican City", "Liechtenstein", "Malta"], ans: 1 },
      { q: "How many continents are there?", opts: ["5", "6", "7", "8"], ans: 2 },
      { q: "What is the currency of Japan?", opts: ["Won", "Yuan", "Yen", "Rupee"], ans: 2 },
      { q: "Who painted the Mona Lisa?", opts: ["Michelangelo", "Leonardo da Vinci", "Raphael", "Donatello"], ans: 1 },
      { q: "What year did the Titanic sink?", opts: ["1910", "1912", "1915", "1920"], ans: 1 },
    ];

    for (const q of gk_questions) {
      await storage.createQuestion({
        quizId: quiz1.id,
        questionText: q.q,
        options: q.opts,
        correctOptionIndex: q.ans
      });
    }

    const quiz2 = await storage.createQuiz({
      title: "Science & Nature",
      description: "Explore the wonders of science and nature."
    });
    
    const sci_questions = [
      { q: "What represents the chemical symbol 'O'?", opts: ["Gold", "Silver", "Oxygen", "Iron"], ans: 2 },
      { q: "How many bones are in the adult human body?", opts: ["206", "208", "210", "212"], ans: 0 },
      { q: "What is the hardest natural substance on Earth?", opts: ["Gold", "Iron", "Diamond", "Platinum"], ans: 2 },
      { q: "What gas do plants absorb from the atmosphere?", opts: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], ans: 1 },
      { q: "What is the speed of light?", opts: ["300,000 km/s", "150,000 km/s", "450,000 km/s", "200,000 km/s"], ans: 0 },
      { q: "How many chambers does a human heart have?", opts: ["2", "3", "4", "5"], ans: 2 },
      { q: "What is the process by which plants make their own food?", opts: ["Respiration", "Photosynthesis", "Fermentation", "Digestion"], ans: 1 },
      { q: "What is the most abundant gas in Earth's atmosphere?", opts: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Argon"], ans: 2 },
      { q: "How many sides does a hexagon have?", opts: ["4", "5", "6", "7"], ans: 2 },
      { q: "What is the boiling point of water at sea level?", opts: ["90°C", "100°C", "110°C", "120°C"], ans: 1 },
    ];

    for (const q of sci_questions) {
      await storage.createQuestion({
        quizId: quiz2.id,
        questionText: q.q,
        options: q.opts,
        correctOptionIndex: q.ans
      });
    }
  }

  return httpServer;
}
