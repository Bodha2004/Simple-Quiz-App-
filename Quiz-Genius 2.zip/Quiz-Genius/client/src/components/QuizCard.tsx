import { Link } from "wouter";
import { ArrowRight, BookOpen, Clock } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Quiz } from "@shared/schema";

interface QuizCardProps {
  quiz: Quiz;
  index: number;
}

export function QuizCard({ quiz, index }: QuizCardProps) {
  // Stagger animation delay based on index
  const style = { animationDelay: `${index * 100}ms` };

  return (
    <Card 
      className="group hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border-border/50 animate-in fade-in slide-in-from-bottom-4 fill-mode-backwards"
      style={style}
    >
      <CardHeader>
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary/20 to-purple-400/20 flex items-center justify-center mb-4 text-primary group-hover:scale-110 transition-transform duration-300">
          <BookOpen className="w-6 h-6" />
        </div>
        <CardTitle className="text-xl group-hover:text-primary transition-colors">{quiz.title}</CardTitle>
        <CardDescription className="line-clamp-2">{quiz.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            <span>5-10 min</span>
          </div>
          {/* We could add difficulty or question count here if we had it in the list view */}
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/quiz/${quiz.id}`} className="w-full">
          <Button className="w-full justify-between group-hover:bg-primary group-hover:text-primary-foreground transition-all">
            Start Quiz
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
