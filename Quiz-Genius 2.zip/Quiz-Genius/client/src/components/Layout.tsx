import { ReactNode } from "react";
import { Link } from "wouter";
import { BrainCircuit } from "lucide-react";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=2029&auto=format&fit=crop')] bg-cover bg-fixed bg-center">
      <div className="min-h-screen bg-background/90 backdrop-blur-sm flex flex-col">
        <header className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-md">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group cursor-pointer">
              <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                <BrainCircuit className="w-6 h-6 text-primary" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight">QuizGenius</span>
            </Link>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-4 py-8 md:py-12">
          {children}
        </main>

        <footer className="border-t border-border/40 py-8 text-center text-muted-foreground text-sm">
          <p>© {new Date().getFullYear()} QuizGenius. Challenge yourself.</p>
        </footer>
      </div>
    </div>
  );
}
