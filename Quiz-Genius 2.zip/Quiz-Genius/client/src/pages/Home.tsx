import { useState } from "react";
import { useLocation } from "wouter";
import { useQuizzes } from "@/hooks/use-quizzes";
import { Layout } from "@/components/Layout";
import { QuizCard } from "@/components/QuizCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Trophy } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function Home() {
  const { data: quizzes, isLoading, error } = useQuizzes();
  const [_, setLocation] = useLocation();
  const [isRandomizing, setIsRandomizing] = useState(false);

  const handleSurpriseMe = () => {
    if (!quizzes || quizzes.length === 0) return;
    setIsRandomizing(true);
    
    // Fake loading effect for excitement
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * quizzes.length);
      const randomQuiz = quizzes[randomIndex];
      setLocation(`/quiz/${randomQuiz.id}`);
    }, 800);
  };

  return (
    <Layout>
      <section className="text-center mb-16 space-y-6">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm animate-in fade-in zoom-in duration-500">
          <Trophy className="w-4 h-4" />
          <span>Test your knowledge today</span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-balance">
          Master Any Subject with <span className="gradient-text">QuizGenius</span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
          Choose from our curated collection of quizzes to challenge yourself and learn something new every day.
        </p>

        <div className="pt-4 flex justify-center gap-4">
          <Button 
            size="lg" 
            variant="outline"
            className="h-12 px-8 text-base border-primary/20 hover:border-primary/50 hover:bg-primary/5"
            onClick={handleSurpriseMe}
            disabled={isLoading || isRandomizing || !quizzes?.length}
          >
            {isRandomizing ? (
              "Picking a challenge..." 
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2 text-primary" />
                Surprise Me
              </>
            )}
          </Button>
        </div>
      </section>

      {error ? (
        <Alert variant="destructive" className="max-w-2xl mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load quizzes. Please try again later.
          </AlertDescription>
        </Alert>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="space-y-4 p-6 rounded-xl border">
                <Skeleton className="h-12 w-12 rounded-lg" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-10 w-full mt-4" />
              </div>
            ))
          ) : quizzes?.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground">No quizzes available at the moment.</p>
            </div>
          ) : (
            quizzes?.map((quiz, index) => (
              <QuizCard key={quiz.id} quiz={quiz} index={index} />
            ))
          )}
        </div>
      )}
    </Layout>
  );
}
