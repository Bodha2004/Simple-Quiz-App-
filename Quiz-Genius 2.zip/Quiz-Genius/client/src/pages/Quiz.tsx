import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuiz } from "@/hooks/use-quizzes";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, XCircle, ChevronRight, RotateCcw, Home } from "lucide-react";
import { cn } from "@/lib/utils";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "framer-motion";

export default function Quiz() {
  const params = useParams();
  const quizId = parseInt(params.id || "0");
  const { data: quiz, isLoading, error } = useQuiz(quizId);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Scroll to top when question changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentQuestionIndex]);

  // Trigger confetti on finish if score is good
  useEffect(() => {
    if (isFinished && score > (quiz?.questions.length || 0) / 2) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#7c3aed', '#ec4899', '#8b5cf6']
      });
    }
  }, [isFinished, score, quiz]);

  if (isLoading) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto space-y-8 animate-pulse">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-4 w-full" />
          <div className="space-y-4">
            <Skeleton className="h-64 w-full rounded-2xl" />
            <div className="space-y-2">
              <Skeleton className="h-14 w-full rounded-xl" />
              <Skeleton className="h-14 w-full rounded-xl" />
              <Skeleton className="h-14 w-full rounded-xl" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !quiz) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-20">
          <h2 className="text-2xl font-bold text-destructive mb-4">Oops!</h2>
          <p className="text-muted-foreground mb-8">We couldn't load that quiz. It might not exist or there was a network error.</p>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex) / quiz.questions.length) * 100;

  const handleSubmit = () => {
    if (selectedOption === null) return;
    
    setIsSubmitted(true);
    if (selectedOption === currentQuestion.correctOptionIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsSubmitted(false);
    } else {
      setIsFinished(true);
    }
  };

  if (isFinished) {
    const percentage = Math.round((score / quiz.questions.length) * 100);
    
    return (
      <Layout>
        <div className="max-w-2xl mx-auto py-12 text-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card rounded-3xl p-8 md:p-12 shadow-2xl border border-border/50"
          >
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <TrophyIcon score={percentage} />
            </div>
            
            <h1 className="text-4xl font-display font-bold mb-2">Quiz Complete!</h1>
            <p className="text-muted-foreground text-lg mb-8">Here's how you did on "{quiz.title}"</p>
            
            <div className="flex justify-center gap-8 mb-12">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary">{score}/{quiz.questions.length}</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold">Score</div>
              </div>
              <div className="w-px bg-border"></div>
              <div className="text-center">
                <div className="text-4xl font-bold text-primary">{percentage}%</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold">Accuracy</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-12 gap-2">
                  <Home className="w-4 h-4" />
                  All Quizzes
                </Button>
              </Link>
              <Button 
                size="lg" 
                className="w-full sm:w-auto h-12 gap-2 bg-primary hover:bg-primary/90"
                onClick={() => window.location.reload()}
              >
                <RotateCcw className="w-4 h-4" />
                Retake Quiz
              </Button>
            </div>
          </motion.div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <div className="mb-8 space-y-2">
          <div className="flex justify-between items-end mb-2">
            <div>
              <h1 className="text-2xl font-bold font-display">{quiz.title}</h1>
              <p className="text-muted-foreground text-sm">Question {currentQuestionIndex + 1} of {quiz.questions.length}</p>
            </div>
            <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
              {Math.round(progress)}% Complete
            </span>
          </div>
          <Progress value={progress} className="h-2 w-full" />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -20, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-0 shadow-lg ring-1 ring-black/5 bg-card/50 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-6 md:p-8">
                <h2 className="text-xl md:text-2xl font-medium mb-8 leading-relaxed">
                  {currentQuestion.questionText}
                </h2>

                <RadioGroup 
                  value={selectedOption?.toString()} 
                  onValueChange={(val) => !isSubmitted && setSelectedOption(parseInt(val))}
                  className="space-y-4"
                >
                  {currentQuestion.options.map((option, idx) => {
                    let itemStateClass = "";
                    
                    if (isSubmitted) {
                      if (idx === currentQuestion.correctOptionIndex) {
                        itemStateClass = "bg-green-500/10 border-green-500 hover:bg-green-500/10 hover:border-green-500";
                      } else if (idx === selectedOption) {
                        itemStateClass = "bg-red-500/10 border-red-500 hover:bg-red-500/10 hover:border-red-500";
                      } else {
                        itemStateClass = "opacity-50";
                      }
                    } else if (selectedOption === idx) {
                      itemStateClass = "border-primary bg-primary/5 ring-1 ring-primary/20";
                    }

                    return (
                      <div key={idx} className="relative">
                        <RadioGroupItem value={idx.toString()} id={`opt-${idx}`} className="sr-only" />
                        <Label
                          htmlFor={`opt-${idx}`}
                          className={cn(
                            "flex items-center p-4 md:p-5 rounded-xl border-2 border-muted cursor-pointer transition-all duration-200 hover:bg-muted/50 hover:border-muted-foreground/30",
                            itemStateClass
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-full border-2 flex items-center justify-center mr-4 shrink-0 font-bold transition-colors",
                            isSubmitted && idx === currentQuestion.correctOptionIndex 
                              ? "border-green-500 bg-green-500 text-white" 
                              : isSubmitted && idx === selectedOption 
                                ? "border-red-500 bg-red-500 text-white"
                                : selectedOption === idx 
                                  ? "border-primary text-primary" 
                                  : "border-muted-foreground/30 text-muted-foreground"
                          )}>
                            {String.fromCharCode(65 + idx)}
                          </div>
                          <span className="text-base md:text-lg flex-1">{option}</span>
                          
                          {isSubmitted && idx === currentQuestion.correctOptionIndex && (
                            <CheckCircle2 className="w-6 h-6 text-green-500 ml-2 animate-in zoom-in" />
                          )}
                          {isSubmitted && idx === selectedOption && idx !== currentQuestion.correctOptionIndex && (
                            <XCircle className="w-6 h-6 text-red-500 ml-2 animate-in zoom-in" />
                          )}
                        </Label>
                      </div>
                    );
                  })}
                </RadioGroup>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="mt-8 flex justify-end">
          {!isSubmitted ? (
            <Button 
              size="lg" 
              className="px-8 h-12 text-base font-medium shadow-lg shadow-primary/20 transition-all hover:shadow-xl hover:translate-y-[-2px] disabled:opacity-50 disabled:translate-y-0 disabled:shadow-none"
              onClick={handleSubmit}
              disabled={selectedOption === null}
            >
              Submit Answer
            </Button>
          ) : (
            <Button 
              size="lg" 
              className="px-8 h-12 text-base font-medium animate-in fade-in slide-in-from-right-4"
              onClick={handleNext}
            >
              {currentQuestionIndex < quiz.questions.length - 1 ? "Next Question" : "See Results"}
              <ChevronRight className="ml-2 w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </Layout>
  );
}

function TrophyIcon({ score }: { score: number }) {
  if (score >= 80) return <span className="text-5xl">🏆</span>;
  if (score >= 60) return <span className="text-5xl">🌟</span>;
  return <span className="text-5xl">📚</span>;
}
