## Packages
canvas-confetti | For celebration effects on results page
framer-motion | For smooth transitions between questions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
}
